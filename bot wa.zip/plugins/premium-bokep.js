//BOKEP BY Yanz_5008

/*let handler = async (m, { conn, text }) => {
    let yh = global.bokep
    let url = yh[Math.floor(Math.random() * yh.length)]
    conn.sendButton(m.chat, '\nSiapkan tisu kak 😅', botdate, url, [['NEXT', '.bokep']], m)
  }
  handler.command = /^(bokep)$/i
  handler.tags = ['premium']
  handler.help = ['bokep']
  handler.premium = true
  export default handler
  
 global.bokep = ["https://raku-web.herokuapp.com/api/bokep?apikey=RakuKeyTod"]*/